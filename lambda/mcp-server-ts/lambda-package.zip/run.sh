#!/bin/bash
exec node dist/handler.js
